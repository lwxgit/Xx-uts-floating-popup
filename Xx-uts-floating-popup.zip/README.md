**uni-app uts插件-android悬浮窗示例**

### 效果图

![效果图](https://github.com/lwxgit/Xx-uts-floating-popup/blob/main/%E6%95%88%E6%9E%9C%E5%9B%BE.jpg?raw=true)
### 注意事项

- 运行前需要打包自定义基座
- 测试运行版本HBuilderX：3.7.11